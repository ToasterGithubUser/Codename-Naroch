arch/i386/idt.o: arch/i386/idt.c include/kernel/idt.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 include/kernel/tty.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/string.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/sys/cdefs.h \
 include/kernel/keyboard.h include/kernel/conversions.h \
 include/kernel/io.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/stdio.h \
 include/kernel/timer.h include/kernel/paging.h arch/i386/vga.h \
 include/kernel/task.h
