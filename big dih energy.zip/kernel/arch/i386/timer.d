arch/i386/timer.o: arch/i386/timer.c include/kernel/timer.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 include/kernel/io.h
