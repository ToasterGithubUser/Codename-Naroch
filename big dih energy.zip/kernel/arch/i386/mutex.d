arch/i386/mutex.o: arch/i386/mutex.c include/kernel/mutex.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 include/kernel/task.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h
