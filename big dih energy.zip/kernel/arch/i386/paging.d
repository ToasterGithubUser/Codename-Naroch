arch/i386/paging.o: arch/i386/paging.c include/kernel/paging.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 include/kernel/pmm.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 include/kernel/idt.h include/kernel/conversions.h include/kernel/tty.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/stdio.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/sys/cdefs.h
