arch/i386/interrupt.o: arch/i386/interrupt.S
