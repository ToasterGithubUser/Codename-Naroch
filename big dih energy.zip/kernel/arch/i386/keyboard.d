arch/i386/keyboard.o: arch/i386/keyboard.c include/kernel/keyboard.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 include/kernel/tty.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 include/kernel/shell.h
