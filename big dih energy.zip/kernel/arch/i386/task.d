arch/i386/task.o: arch/i386/task.c include/kernel/task.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 include/kernel/heap.h include/kernel/idt.h
