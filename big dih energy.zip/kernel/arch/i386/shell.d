arch/i386/shell.o: arch/i386/shell.c include/kernel/shell.h \
 include/kernel/tty.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/stdio.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/sys/cdefs.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/string.h \
 include/kernel/conversions.h arch/i386/vga.h include/kernel/build_no.h \
 include/kernel/timer.h include/kernel/pmm.h include/kernel/heap.h
