arch/i386/pmm.o: arch/i386/pmm.c include/kernel/pmm.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/string.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/sys/cdefs.h
