arch/i386/tty.o: arch/i386/tty.c \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdbool.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/string.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/sys/cdefs.h \
 include/kernel/tty.h include/kernel/heap.h arch/i386/vga.h \
 include/kernel/mutex.h
