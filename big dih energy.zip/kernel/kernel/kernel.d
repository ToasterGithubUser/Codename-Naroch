kernel/kernel.o: kernel/kernel.c \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/stdio.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/sys/cdefs.h \
 include/kernel/gdt.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h \
 include/kernel/idt.h include/kernel/tty.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 include/kernel/shell.h include/kernel/build_no.h \
 include/kernel/conversions.h include/kernel/timer.h include/kernel/pmm.h \
 include/kernel/multiboot.h include/kernel/paging.h include/kernel/heap.h \
 include/kernel/task.h
