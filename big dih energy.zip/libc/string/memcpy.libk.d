string/memcpy.libk.o: string/memcpy.c include/string.h \
 include/sys/cdefs.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h
