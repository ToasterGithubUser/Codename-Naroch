stdio/printf.libk.o: stdio/printf.c \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/limits.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdbool.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdarg.h \
 include/stdio.h include/sys/cdefs.h include/string.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/kernel/mutex.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h
