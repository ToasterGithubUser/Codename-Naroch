stdio/putchar.libk.o: stdio/putchar.c include/stdio.h include/sys/cdefs.h \
 /home/andre/src/Codename_Naroch/meaty-skeleton/sysroot/usr/include/kernel/tty.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stddef.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint.h \
 /home/andre/opt/cross/lib/gcc/i686-elf/17.0.0/include/stdint-gcc.h
